const API_BASE_URL = process.env.REACT_APP_API_URL || 'https://test-ssto-project.local:5173';

export default {
  API_BASE_URL,
};